
# qt_myapp.py

import sys

from PySide6.QtWidgets import QApplication, QWidget
from PySide6.QtGui import QPainter, QColor, QFont, QPen, QBrush
from PySide6.QtCore import Qt, QRect

class MyAppWindow(QWidget):
    def __init__(self):
        # your code here
        ...
        
        super().__init__()
        self.initUI()

    def initUI(self):
        self.setWindowTitle("qt_app")
        self.resize(300,200)
        self.show()

    def paintEvent(self, ev):
        ctx = QPainter()
        w, h = self.width(), self.height()
        ctx.begin(self)

        # your code here
        ...
        
        ctx.end()

    def mousePressEvent(self, ev):
        pos=ev.position()
        x,y = int(pos.x()), int(pos.y())
        # your code here
        ...

    def add_widget(self, w):
        self.widgets.append(w)
        

