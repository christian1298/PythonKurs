

# myapp.py

class MyApp:    
    def __init__(self):
        self.running = False
        self.want_redraw = True
        self.events = [(10,0), (20, 10), (50, 5)]
        self.cycle = 0
        self.widgets = []

    def add_widget(self, w):
        self.widgets.append(w)

    def redraw(self):
        ctx = None
        for w in self.widgets: w.draw(ctx)
        self.want_redraw = False

    def run(self):
        self.running = True
        self.want_redraw = True

        while self.running:
            if self.cycle > 10: break
            if self.want_redraw: self.redraw()
            x,y = self.get_mouse_xy()            
            for item in self.widgets:
                if item.contains(x, y):
                    print(f"click ({x},{y}) inside", item)
                    item.handle_mouse(x, y)

    def exit(self):
        self.running = False

    def get_mouse_xy(self):
        nevents = len(self.events)
        if self.cycle >= nevents: return 0,0
        xy = self.events[self.cycle]
        self.cycle += 1
        return xy  
