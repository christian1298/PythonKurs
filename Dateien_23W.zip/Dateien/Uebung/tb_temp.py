

# tb_temp.py

import temperature



T=temperature.celsius2kelvin(10)
print(T)
