# tb_temperature.py

from temperature import celsius2kelvin as c2k
import temperature as t


print(c2k(35), t.celsius2kelvin(35))
print(t.celsius2fahrenheit(-10))
