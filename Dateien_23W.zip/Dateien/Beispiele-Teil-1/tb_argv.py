
# tb_argv.py

import sys

if __name__ == "__main__": print(sys.argv)

